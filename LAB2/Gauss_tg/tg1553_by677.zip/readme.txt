Use 'make' to complie. Use './run' to execute the program with config file 'cacheconfig.txt' and 'trace.txt'. The result will be in 'trace.txt.out'. 

Use './cachesimulator configfilename tracefilename' to execute with custom config file.
